import React, { useState } from 'react'

const UserDetails = () => {
    const [address, setAddress] = useState({
        houseNo: "",
        streetName: "",
        landMark: "",
        country: "",
        state: "",
        city: ""
    })
    const [firstName, setFirstName] = useState("")
    const [lastName, setLastName] = useState("")
    const [profilePic, setProfilePic] = useState("")
    const [users, setUsers] = useState([])
    const [updateId, setUpdateId] = useState(null)
    const [toggle, setToggle] = useState(false)
    const [addAddress,setAddAddress]=useState([])

    //error state
    const[firstNameErr,setFirstNameErr]=useState('')
    const[lastNameErr,setLastNameErr]=useState('')
    const[houseNoErr,setHouseNoErr]=useState('')
    const[streetNameErr,setStreetNameErr]=useState('')
    const[landMarkErr,setLandMarkErr]=useState('')
    const[countryErr,setCountryErr]=useState('')
    const[stateErr,setStateErr]=useState('')
    const[cityErr,setCityErr]=useState('')


    //validate user
    // const formValidate=()=>{
    //     const formValid = true

    //     if(firstName ===""){
    //         formValid=false
    //         setFirstNameErr("Please Enter First Name")
    //     }

    //     if(lastName ===""){
    //         formValid=false
    //         setLastNameErr("Please Enter Last Name")
    //     }
    //     if(address.houseNo ===""){
    //         formValid=false
    //         setHouseNoErr("Please Enter House number")
    //     }
    //     if(address.landMark ===""){
    //         formValid=false
    //         setLandMarkErr("Please Enter land mark")
    //     }
    //     if(address.country ===""){
    //         formValid=false
    //         setCountryErr("Please Enter Country Name")
    //     }
    //     if(address.state ===""){
    //         formValid=false
    //         setStateErr("Please Enter state Name")
    //     }
    //     if(address.city ===""){
    //         formValid=false
    //         setCityErr("Please Enter City Name")
    //     }
    //    return formValid
    // }



    // onHndleChange
    const handleChange = (e) => {
        const { name, value } = e.target
        setAddress({ ...address, [name]: value })
    }


    // save user data
    const handleSubmit = (e) => {
        e.preventDefault()
        // formValidate()
        if (firstName === "" && lastName === "" && address.houseNo === "" && address.city === "" && address.country === "" && address.landMark === "" && address.state === "") {
            alert("Please fill all the fields")
        }
        else if(updateId && toggle){
            setUsers(
                users.map((userUpdate)=>{
                    if(userUpdate.id ===updateId){
                        return {...userUpdate,firstName, lastName, profilePic, address}
                    }
                    return userUpdate
                })
            )
        }
        else {
            setUsers([...users, { id: users.length + 1, firstName, lastName, profilePic, address }])
            // localStorage.setItem("user",JSON.stringify({ id: new Date(), firstName, lastName, profilePic, address }))
        }

        setFirstName("")
        setLastName("")
        setProfilePic("")
        setAddress({
            houseNo: "",
            streetName: "",
            landMark: "",
            country: "",
            state: "",
            city: ""
        })
        setToggle(false)
        setUpdateId(null)
    }


    // Delete user
    const handleDelete = (id) => {
        const deleteUser = users.filter((user) => user.id !== id)
        setUsers(deleteUser)
    }

    // update user
    const handleUpdate = (user) => {
        setToggle(true)
        setUpdateId(user.id)
        setFirstName(user.firstName)
        setLastName(user.lastName)
        setProfilePic(user.profilePic)
        setAddress({
            houseNo: user.address.houseNo,
            streetName: user.address.streetName,
            landMark: user.address.landMark,
            country: user.address.country,
            state: user.address.state,
            city: user.address.city
        })
    }

    const handleAddMoreAddress = ()=>{
        setAddAddress([...addAddress,{id:addAddress.length}])
    }
    return (
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>
                        First Name<span style={{color:"red"}}>*</span>
                        <input type='text' placeholder='Enter First Name' value={firstName} onChange={(e) => setFirstName(e.target.value)} />
                        {/* {firstNameErr && <span>{firstNameErr}</span>} */}
                    </label>
                    <label>
                        Last Name<span style={{color:"red"}}>*</span>
                        <input type='text' placeholder='Enter Last Name' value={lastName} onChange={(e) => setLastName(e.target.value)} />
                    </label>
                    <label>
                        Profile Pic<span>(optional)</span>
                        <input type='file' onChange={(e) => setProfilePic(e.target.files[0])} />
                    </label>
                </div>
                {/* {addAddress.map((list,id)=>{
                    return(
                        <div>
                        <label>
                            <span>House No.</span>
                            <input type='text' placeholder='Enter House No' name='houseNo' value={address.houseNo} onChange={handleChange} />
                        </label>
                        <label>
                            <span>Street Name</span>
                            <input type='text' placeholder='Enter Street Name' name='streetName' value={address.streetName} onChange={handleChange} />
                        </label><br/>
                         <label>
                            <span>Land Mark</span>
                            <input type='text' placeholder='Enter Land Mark' name='landMark' value={address.landMark} onChange={handleChange} />
                        </label> 
                        <label>
                            <span>Country Name</span>
                            <input type='text' placeholder='Enter Country' name="country" value={address.country} onChange={handleChange} />
                        </label><br/>
                         <label>
                            <span>State Name</span>
                            <input type='text' placeholder='Enter State Name' name='state' value={address.state} onChange={handleChange} />
                        </label>
                        <label>
                            <span>City Name</span>
                            <input type='text' placeholder='Enter City Name' name='city' value={address.city} onChange={handleChange} />
                        </label>
                        <button onClick={handleAddMoreAddress}>Add more address</button>
                    </div>
                    )
                })} */}
                <div>
                    <label>
                        House No.<span style={{color:"red"}}>*</span>
                        <input type='text' placeholder='Enter House No' name='houseNo' value={address.houseNo} onChange={handleChange} />
                    </label>
                    <label>
                        Street Name<span style={{color:"red"}}>*</span>
                        <input type='text' placeholder='Enter Street Name' name='streetName' value={address.streetName} onChange={handleChange} />
                    </label><br/>
                     <label>
                        Land Mark<span style={{color:"red"}}>*</span>
                        <input type='text' placeholder='Enter Land Mark' name='landMark' value={address.landMark} onChange={handleChange} />
                    </label> 
                    <label>
                        Country Name<span style={{color:"red"}}>*</span>
                        <input type='text' placeholder='Enter Country' name="country" value={address.country} onChange={handleChange} />
                    </label><br/>
                     <label>
                        State Name<span style={{color:"red"}}>*</span>
                        <input type='text' placeholder='Enter State Name' name='state' value={address.state} onChange={handleChange} />
                    </label>
                    <label>
                        City Name<span style={{color:"red"}}>*</span>
                        <input type='text' placeholder='Enter City Name' name='city' value={address.city} onChange={handleChange} />
                    </label>
                    
                </div>
                <div>
                    <button>{toggle ? "Update User" :"Add user"}</button>
                </div>
            </form>
                <div>
                    {users.map((user, id) => {
                        return (
                            <div className='card' key={id}>
                                <div>
                                    <p>{user.firstName}</p>
                                    <p>{user.lastName}</p>
                                </div>
                                <div>
                                    <img src={user.profilePic} alt='Profile pics' />
                                </div>
                                <div>
                                    <p>{user.address.houseNo}</p>
                                    <p>{user.address.streetName}</p>
                                    <p>{user.address.landMark}</p>
                                    <p>{user.address.country}</p>
                                    <p>{user.address.state}</p>
                                    <p>{user.address.city}</p>
                                </div>
                                <div>
                                    <button onClick={() => handleDelete(user.id)}>Delete</button>
                                    <button onClick={() => handleUpdate(user)}>Update</button>
                                </div>
                            </div>
                        )
                    })}
                </div>
        </div>
    )
}

export default UserDetails