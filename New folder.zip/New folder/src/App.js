import React from 'react'
import "./App.css"
import UserDetails from './page/UserDetails'
const App = () => {
  return (
    <>
    <UserDetails/>
    </>
  )
}

export default App